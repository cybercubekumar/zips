from flask import Flask, request, render_template, render_template_string, redirect, session, make_response
import csv
import os
from datetime import datetime

app = Flask(__name__)
app.secret_key = "super_secret_key"

FLAG = "JTI1JTM0JTMzJTI1JTM1JTM5JTI1JTM0JTMyJTI1JTM0JTM1JTI1JTM1JTMyJTI1JTM0JTMzJTI1JTM1JTM1JTI1JTM0JTMyJTI1JTM0JTM1JTI1JTM3JTYyJTI1JTM1JTMzJTI1JTM1JTMzJTI1JTM1JTM0JTI1JTM0JTM5JTI1JTM1JTY2JTI1JTM1JTM4JTI1JTM1JTMzJTI1JTM1JTMzJTI1JTM1JTY2JTI1JTM0JTY2JTI1JTM1JTM3JTI1JTM0JTY1JTI1JTM0JTM1JTI1JTM0JTM0JTI1JTM3JTY0"
CSV_FILE = "user_flags.csv"  # 🔥 Added: CSV file for scoreboard

# 🔥 Ensure CSV file exists with header
if not os.path.exists(CSV_FILE):
    with open(CSV_FILE, "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["username", "status"])

@app.after_request
def add_header(response):
    response.headers["Cache-Control"] = "no-store, no-cache, must-revalidate, post-check=0, pre-check=0, max-age=0"
    response.headers["Pragma"] = "no-cache"
    response.headers["Expires"] = "1"
    return response

@app.route("/", methods=["GET", "POST"])
def index():
    if request.method == "POST":
        username = request.form.get("username")
        session['username'] = username

        # 🔥 Save username to CSV if not already present
        existing_users = []
        with open(CSV_FILE, "r") as f:
            reader = csv.DictReader(f)
            for row in reader:
                existing_users.append(row["username"])

        if username not in existing_users:
            with open(CSV_FILE, "a", newline="") as f:
                writer = csv.writer(f)
                writer.writerow([username, "fail"])

        return redirect("/dashboard")
    return render_template("index.html")

@app.route("/dashboard", methods=["GET", "POST"])
def dashboard():
    username = session.get('username')
    if not username:
        return redirect("/")

    search_query = ""
    if request.method == "POST":
        search_query = request.form.get("search", "")
        return render_template_string(f"Search results for: {search_query}")  # ⚠️ SSTI

    return render_template("dashboard.html", username=username, search_query=search_query)

@app.route("/login", methods=["POST"])
def login():
    username = request.form.get("username")
    password = request.form.get("password")

    if username == "cyberhero" and password == "ssti_xss_master":
        session.clear()
        session["user"] = username
        session["authenticated"] = True
        response = make_response(redirect("/messages"))
        response.set_cookie("flag", FLAG, httponly=False)
        return response

    return "HAHAHAHA! Please try again."

@app.route("/messages", methods=["GET", "POST"])
def messages_page():
    if "user" not in session:
        return redirect("/")

    if request.method == "POST":
        message = request.form.get("message")
        session["message"] = message

    return render_template("messages.html", message=session.get("message"))

@app.route("/submit-flag", methods=["GET", "POST"])
def submit_flag():
    if request.method == "POST":
        submitted_flag = request.form.get("flag")
        username = session.get("username")

        if submitted_flag == FLAG:
            # 🔥 Update CSV status to pass
            updated_rows = []
            with open(CSV_FILE, "r") as f:
                reader = csv.DictReader(f)
                for row in reader:
                    if row["username"] == username:
                        row["status"] = "pass"
                    updated_rows.append(row)

            with open(CSV_FILE, "w", newline="") as f:
                writer = csv.DictWriter(f, fieldnames=["username", "status"])
                writer.writeheader()
                writer.writerows(updated_rows)

            return "🎉 Congratulations! You captured the flag!"
        return "❌ Incorrect flag. Try again."

    return render_template("submit_flag.html")

@app.route("/logout")
def logout():
    session.clear()
    resp = make_response(render_template("logout.html"))
    resp.set_cookie("flag", "", expires=0)
    return resp

# ✅ SCOREBOARD ROUTE
@app.route("/scoreboard")
def scoreboard():
    with open(CSV_FILE, "r") as f:
        reader = csv.DictReader(f)
        users = list(reader)
    return render_template("scoreboard.html", users=users)

# For admin page
@app.route("/admin", methods=["GET", "POST"])
def admin_login():
    if request.method == "POST":
        password = request.form.get("password")
        if password == "ctf_admin_123":  # Change this password as needed
            with open('user_flags.csv', 'r') as f:
                reader = csv.DictReader(f)
                users = list(reader)
            return render_template("admin.html", users=users)
        else:
            return render_template("admin_login.html", error="❌ Wrong password!")
    return render_template("admin_login.html")


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=False)
