// FLAG 3/5: Assemble

console.log("Welcome elite hacker. Not everything is visible to the naked eye.");
